﻿# Eldritch-Dreams-Castlevania-PF2e
To install the module on Foundry, navigate to the latest release, Right Click "module.json" and copy the link. paste the link in the Manifest URL field at the bottom of the Install Module window in foundry!

## Current Contents
- Buer
- Debiru
- Ectoplasm
- Gaibon
- Legion
- Persephone
- Plate Lord
- Slogra
- Stone Rose
